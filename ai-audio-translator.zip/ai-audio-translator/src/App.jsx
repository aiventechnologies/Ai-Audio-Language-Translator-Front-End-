import { useState } from 'react'
import Header from './components/Header.jsx'
import Recorder from './components/Recorder.jsx'
import LanguageSelector from './components/LanguageSelector.jsx'
import TranscriptPanel from './components/TranscriptPanel.jsx'
import HistoryList from './components/HistoryList.jsx'
import Footer from './components/Footer.jsx'
import { transcribeAudio, translateText } from './lib/api.js'

export default function App() {
  const [sourceLang, setSourceLang] = useState('en')
  const [targetLang, setTargetLang] = useState('ur')
  const [status, setStatus] = useState('idle') // idle | transcribing | translating | done | error
  const [transcript, setTranscript] = useState('')
  const [translation, setTranslation] = useState('')
  const [history, setHistory] = useState([])

  const isProcessing = status === 'transcribing' || status === 'translating'

  async function handleAudioReady(blob) {
    setTranscript('')
    setTranslation('')
    setStatus('transcribing')
    try {
      const { text } = await transcribeAudio(blob, sourceLang)
      setTranscript(text)

      setStatus('translating')
      const { translatedText } = await translateText(text, sourceLang, targetLang)
      setTranslation(translatedText)
      setStatus('done')

      setHistory((prev) => [
        { id: crypto.randomUUID(), sourceLang, targetLang, transcript: text, translation: translatedText },
        ...prev,
      ].slice(0, 8))
    } catch (err) {
      setStatus('error')
    }
  }

  function handleSwap() {
    setSourceLang(targetLang)
    setTargetLang(sourceLang)
  }

  function handleSelectHistory(item) {
    setSourceLang(item.sourceLang)
    setTargetLang(item.targetLang)
    setTranscript(item.transcript)
    setTranslation(item.translation)
    setStatus('done')
  }

  return (
    <>
      <Header />

      <section className="controls-block">
        <LanguageSelector
          sourceLang={sourceLang}
          targetLang={targetLang}
          onChangeSource={setSourceLang}
          onChangeTarget={setTargetLang}
          onSwap={handleSwap}
        />
        <Recorder onAudioReady={handleAudioReady} isProcessing={isProcessing} />
      </section>

      <TranscriptPanel
        status={status}
        transcript={transcript}
        translation={translation}
        sourceLang={sourceLang}
        targetLang={targetLang}
      />

      {status === 'error' && (
        <p className="error-msg">Something went wrong processing that audio. Please try again.</p>
      )}

      <HistoryList items={history} onSelect={handleSelectHistory} />

      <Footer />

      <style>{`
        .controls-block {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }
        .error-msg {
          color: var(--coral);
          font-size: 14px;
          margin-top: 12px;
        }
      `}</style>
    </>
  )
}
