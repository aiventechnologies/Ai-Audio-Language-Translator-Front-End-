export default function Header() {
  return (
    <header className="header">
      <div className="header-mark" aria-hidden="true">
        <svg width="34" height="34" viewBox="0 0 34 34" fill="none">
          <circle cx="17" cy="17" r="16" stroke="#f2b705" strokeWidth="1.4" />
          <path d="M10 17 L14 12 L14 22 Z" fill="#f2b705" />
          <path d="M24 17 L20 12 L20 22 Z" fill="#8c7ae6" />
        </svg>
      </div>
      <div>
        <p className="eyebrow">Voxbridge</p>
        <h1>Speak once, understood everywhere</h1>
        <p className="header-sub">
          Record or upload audio, choose your languages, and get a transcript
          and translation back in seconds.
        </p>
      </div>

      <style>{`
        .header {
          display: flex;
          align-items: flex-start;
          gap: 16px;
          padding: 56px 0 40px;
        }
        .header-mark {
          flex-shrink: 0;
          margin-top: 6px;
        }
        h1 {
          font-size: clamp(28px, 4vw, 40px);
          line-height: 1.1;
          margin: 6px 0 10px;
        }
        .header-sub {
          margin: 0;
          max-width: 52ch;
          color: var(--ink-dim);
          font-size: 15px;
          line-height: 1.5;
        }
        @media (max-width: 560px) {
          .header { flex-direction: column; }
        }
      `}</style>
    </header>
  )
}
