export default function Footer() {
  return (
    <footer className="footer">
      <span>Voxbridge — frontend demo. Connect a real speech + translation API in src/lib/api.js.</span>
      <style>{`
        .footer {
          margin-top: 64px;
          padding-top: 24px;
          border-top: 1px solid var(--ground-line);
          color: var(--ink-faint);
          font-size: 12px;
          font-family: var(--font-mono);
        }
      `}</style>
    </footer>
  )
}
