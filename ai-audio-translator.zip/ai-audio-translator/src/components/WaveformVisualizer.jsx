import { useEffect, useRef } from 'react'

// Signature element: a live amber/violet spectrum that reacts to the
// microphone while recording, and settles into a gentle idle breathing
// pattern otherwise.
export default function WaveformVisualizer({ analyser, isActive }) {
  const canvasRef = useRef(null)
  const rafRef = useRef(null)
  const idlePhase = useRef(0)

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    const barCount = 48
    const dataArray = analyser ? new Uint8Array(analyser.frequencyBinCount) : null

    function resize() {
      const dpr = window.devicePixelRatio || 1
      canvas.width = canvas.clientWidth * dpr
      canvas.height = canvas.clientHeight * dpr
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    resize()
    window.addEventListener('resize', resize)

    function draw() {
      const w = canvas.clientWidth
      const h = canvas.clientHeight
      ctx.clearRect(0, 0, w, h)

      const gap = 4
      const barWidth = (w - gap * (barCount - 1)) / barCount

      for (let i = 0; i < barCount; i++) {
        let value
        if (isActive && analyser && dataArray) {
          analyser.getByteFrequencyData(dataArray)
          const idx = Math.floor((i / barCount) * dataArray.length)
          value = dataArray[idx] / 255
        } else {
          idlePhase.current += 0.02
          value = 0.14 + 0.10 * Math.sin(idlePhase.current + i * 0.4)
        }

        const barHeight = Math.max(4, value * h)
        const x = i * (barWidth + gap)
        const y = (h - barHeight) / 2

        ctx.fillStyle = i % 2 === 0 ? '#f2b705' : '#8c7ae6'
        ctx.globalAlpha = isActive ? 0.95 : 0.5
        roundRect(ctx, x, y, barWidth, barHeight, barWidth / 2)
        ctx.fill()
      }

      rafRef.current = requestAnimationFrame(draw)
    }

    draw()
    return () => {
      cancelAnimationFrame(rafRef.current)
      window.removeEventListener('resize', resize)
    }
  }, [analyser, isActive])

  return (
    <div className="waveform">
      <canvas ref={canvasRef} />
      <style>{`
        .waveform {
          width: 100%;
          height: 96px;
        }
        .waveform canvas {
          width: 100%;
          height: 100%;
          display: block;
        }
      `}</style>
    </div>
  )
}

function roundRect(ctx, x, y, width, height, radius) {
  ctx.beginPath()
  ctx.moveTo(x + radius, y)
  ctx.arcTo(x + width, y, x + width, y + height, radius)
  ctx.arcTo(x + width, y + height, x, y + height, radius)
  ctx.arcTo(x, y + height, x, y, radius)
  ctx.arcTo(x, y, x + width, y, radius)
  ctx.closePath()
}
