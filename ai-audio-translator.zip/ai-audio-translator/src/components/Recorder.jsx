import { useEffect, useRef, useState } from 'react'
import WaveformVisualizer from './WaveformVisualizer.jsx'

export default function Recorder({ onAudioReady, isProcessing }) {
  const [isRecording, setIsRecording] = useState(false)
  const [elapsed, setElapsed] = useState(0)
  const [error, setError] = useState(null)

  const mediaRecorderRef = useRef(null)
  const chunksRef = useRef([])
  const streamRef = useRef(null)
  const analyserRef = useRef(null)
  const audioCtxRef = useRef(null)
  const timerRef = useRef(null)
  const fileInputRef = useRef(null)

  useEffect(() => {
    return () => stopStream()
  }, [])

  async function startRecording() {
    setError(null)
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      streamRef.current = stream

      const audioCtx = new (window.AudioContext || window.webkitAudioContext)()
      const source = audioCtx.createMediaStreamSource(stream)
      const analyser = audioCtx.createAnalyser()
      analyser.fftSize = 128
      source.connect(analyser)
      audioCtxRef.current = audioCtx
      analyserRef.current = analyser

      const recorder = new MediaRecorder(stream)
      chunksRef.current = []
      recorder.ondataavailable = (e) => chunksRef.current.push(e.data)
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' })
        onAudioReady(blob)
        stopStream()
      }
      recorder.start()
      mediaRecorderRef.current = recorder

      setIsRecording(true)
      setElapsed(0)
      timerRef.current = setInterval(() => setElapsed((s) => s + 1), 1000)
    } catch (err) {
      setError('Microphone access was denied or is unavailable. You can upload a file instead.')
    }
  }

  function stopRecording() {
    mediaRecorderRef.current?.stop()
    clearInterval(timerRef.current)
    setIsRecording(false)
  }

  function stopStream() {
    streamRef.current?.getTracks().forEach((t) => t.stop())
    audioCtxRef.current?.close?.()
  }

  function handleFileUpload(e) {
    const file = e.target.files?.[0]
    if (file) onAudioReady(file)
    e.target.value = ''
  }

  return (
    <div className="recorder">
      <WaveformVisualizer analyser={analyserRef.current} isActive={isRecording} />

      <div className="recorder-controls">
        <button
          type="button"
          className={`record-btn ${isRecording ? 'is-recording' : ''}`}
          onClick={isRecording ? stopRecording : startRecording}
          disabled={isProcessing}
        >
          <span className="dot" />
          {isRecording ? `Stop · ${formatTime(elapsed)}` : 'Start recording'}
        </button>

        <span className="or">or</span>

        <button
          type="button"
          className="upload-btn"
          onClick={() => fileInputRef.current?.click()}
          disabled={isProcessing || isRecording}
        >
          Upload audio file
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="audio/*"
          hidden
          onChange={handleFileUpload}
        />
      </div>

      {error && <p className="recorder-error">{error}</p>}

      <style>{`
        .recorder {
          background: var(--ground-raised);
          border: 1px solid var(--ground-line);
          border-radius: var(--radius);
          padding: 24px;
          box-shadow: var(--shadow-soft);
        }
        .recorder-controls {
          display: flex;
          align-items: center;
          gap: 14px;
          margin-top: 18px;
          flex-wrap: wrap;
        }
        .record-btn {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          background: var(--signal);
          color: #1a1625;
          border: none;
          font-weight: 600;
          font-size: 14px;
          padding: 12px 20px;
          border-radius: 999px;
          transition: transform 0.12s ease, background 0.15s ease;
        }
        .record-btn:hover:not(:disabled) { transform: translateY(-1px); }
        .record-btn:disabled { opacity: 0.6; cursor: not-allowed; }
        .record-btn .dot {
          width: 9px;
          height: 9px;
          border-radius: 50%;
          background: #1a1625;
        }
        .record-btn.is-recording {
          background: var(--coral);
          color: #1a1625;
        }
        .record-btn.is-recording .dot {
          background: #1a1625;
          animation: pulse 1.1s ease-in-out infinite;
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(0.8); }
        }
        .or {
          color: var(--ink-faint);
          font-family: var(--font-mono);
          font-size: 12px;
        }
        .upload-btn {
          background: transparent;
          color: var(--ink);
          border: 1px solid var(--ground-line);
          padding: 12px 18px;
          border-radius: 999px;
          font-size: 14px;
        }
        .upload-btn:hover:not(:disabled) { border-color: var(--violet); color: var(--violet); }
        .upload-btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .recorder-error {
          margin: 14px 0 0;
          color: var(--coral);
          font-size: 13px;
        }
      `}</style>
    </div>
  )
}

function formatTime(seconds) {
  const m = Math.floor(seconds / 60).toString().padStart(2, '0')
  const s = (seconds % 60).toString().padStart(2, '0')
  return `${m}:${s}`
}
