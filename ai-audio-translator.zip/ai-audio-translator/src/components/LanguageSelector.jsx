import { LANGUAGES } from '../lib/languages'

export default function LanguageSelector({ sourceLang, targetLang, onChangeSource, onChangeTarget, onSwap }) {
  return (
    <div className="lang-row">
      <label className="lang-field">
        <span className="lang-label">From</span>
        <select value={sourceLang} onChange={(e) => onChangeSource(e.target.value)}>
          {LANGUAGES.map((l) => (
            <option key={l.code} value={l.code}>{l.label}</option>
          ))}
        </select>
      </label>

      <button type="button" className="swap-btn" onClick={onSwap} aria-label="Swap languages">
        ⇄
      </button>

      <label className="lang-field">
        <span className="lang-label">To</span>
        <select value={targetLang} onChange={(e) => onChangeTarget(e.target.value)}>
          {LANGUAGES.map((l) => (
            <option key={l.code} value={l.code}>{l.label}</option>
          ))}
        </select>
      </label>

      <style>{`
        .lang-row {
          display: flex;
          align-items: flex-end;
          gap: 12px;
        }
        .lang-field {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 6px;
        }
        .lang-label {
          font-family: var(--font-mono);
          font-size: 11px;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: var(--ink-faint);
        }
        select {
          background: var(--ground);
          border: 1px solid var(--ground-line);
          color: var(--ink);
          padding: 10px 12px;
          border-radius: var(--radius-sm);
          font-size: 14px;
          font-family: var(--font-body);
        }
        select:hover { border-color: var(--signal-dim); }
        .swap-btn {
          background: var(--ground-raised);
          border: 1px solid var(--ground-line);
          color: var(--signal);
          width: 38px;
          height: 38px;
          border-radius: 50%;
          font-size: 16px;
          line-height: 1;
          transition: transform 0.15s ease, border-color 0.15s ease;
        }
        .swap-btn:hover {
          border-color: var(--signal);
          transform: rotate(180deg);
        }
        @media (max-width: 520px) {
          .lang-row { flex-wrap: wrap; }
          .swap-btn { order: 3; margin: 0 auto; }
        }
      `}</style>
    </div>
  )
}
