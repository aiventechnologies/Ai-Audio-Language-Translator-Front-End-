import { useState } from 'react'
import { labelFor } from '../lib/languages'

export default function TranscriptPanel({ status, transcript, translation, sourceLang, targetLang }) {
  const [copied, setCopied] = useState('')

  function copy(text, which) {
    navigator.clipboard?.writeText(text)
    setCopied(which)
    setTimeout(() => setCopied(''), 1500)
  }

  if (status === 'idle') {
    return (
      <div className="panel empty">
        <p className="empty-title">Nothing translated yet</p>
        <p className="empty-sub">Record or upload audio above to see the transcript and translation here.</p>
        <style>{panelStyles}</style>
      </div>
    )
  }

  return (
    <div className="panel">
      <div className="col">
        <div className="col-head">
          <span className="eyebrow">{labelFor(sourceLang)} · Transcript</span>
          {transcript && (
            <button className="copy-btn" onClick={() => copy(transcript, 'source')}>
              {copied === 'source' ? 'Copied' : 'Copy'}
            </button>
          )}
        </div>
        <p className="text">
          {status === 'transcribing' ? <Skeleton /> : transcript}
        </p>
      </div>

      <div className="divider" aria-hidden="true" />

      <div className="col">
        <div className="col-head">
          <span className="eyebrow" style={{ color: 'var(--violet)' }}>
            {labelFor(targetLang)} · Translation
          </span>
          {translation && (
            <button className="copy-btn" onClick={() => copy(translation, 'target')}>
              {copied === 'target' ? 'Copied' : 'Copy'}
            </button>
          )}
        </div>
        <p className="text">
          {status === 'translating' || status === 'transcribing' ? <Skeleton /> : translation}
        </p>
      </div>

      <style>{panelStyles}</style>
    </div>
  )
}

function Skeleton() {
  return (
    <span className="skeleton">
      <span />
      <span />
      <span />
    </span>
  )
}

const panelStyles = `
  .panel {
    background: var(--ground-raised);
    border: 1px solid var(--ground-line);
    border-radius: var(--radius);
    padding: 24px;
    display: flex;
    gap: 24px;
    margin-top: 20px;
  }
  .panel.empty {
    text-align: center;
    padding: 48px 24px;
    display: block;
  }
  .empty-title {
    font-family: var(--font-display);
    font-size: 18px;
    margin: 0 0 6px;
  }
  .empty-sub {
    color: var(--ink-faint);
    font-size: 14px;
    margin: 0;
  }
  .col { flex: 1; min-width: 0; }
  .col-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 10px;
  }
  .text {
    font-size: 15px;
    line-height: 1.6;
    color: var(--ink);
    white-space: pre-wrap;
    word-break: break-word;
    margin: 0;
    min-height: 48px;
  }
  .copy-btn {
    background: none;
    border: none;
    color: var(--ink-faint);
    font-family: var(--font-mono);
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.06em;
  }
  .copy-btn:hover { color: var(--signal); }
  .divider {
    width: 1px;
    background: var(--ground-line);
    flex-shrink: 0;
  }
  .skeleton {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  .skeleton span {
    display: block;
    height: 12px;
    border-radius: 4px;
    background: linear-gradient(90deg, var(--ground-line), var(--ground), var(--ground-line));
    background-size: 200% 100%;
    animation: shimmer 1.3s ease-in-out infinite;
  }
  .skeleton span:nth-child(1) { width: 90%; }
  .skeleton span:nth-child(2) { width: 75%; }
  .skeleton span:nth-child(3) { width: 60%; }
  @keyframes shimmer {
    0% { background-position: 200% 0; }
    100% { background-position: -200% 0; }
  }
  @media (max-width: 640px) {
    .panel { flex-direction: column; }
    .divider { width: 100%; height: 1px; }
  }
`
