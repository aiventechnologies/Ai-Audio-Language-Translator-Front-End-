import { labelFor } from '../lib/languages'

export default function HistoryList({ items, onSelect }) {
  if (items.length === 0) return null

  return (
    <div className="history">
      <span className="eyebrow">Session history</span>
      <ul>
        {items.map((item) => (
          <li key={item.id}>
            <button onClick={() => onSelect(item)}>
              <span className="history-langs">
                {labelFor(item.sourceLang)} → {labelFor(item.targetLang)}
              </span>
              <span className="history-snippet">{item.translation.slice(0, 64)}{item.translation.length > 64 ? '…' : ''}</span>
            </button>
          </li>
        ))}
      </ul>

      <style>{`
        .history { margin-top: 32px; }
        .history ul {
          list-style: none;
          margin: 12px 0 0;
          padding: 0;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .history button {
          width: 100%;
          text-align: left;
          background: transparent;
          border: 1px solid var(--ground-line);
          border-radius: var(--radius-sm);
          padding: 12px 14px;
          color: var(--ink);
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .history button:hover {
          border-color: var(--signal-dim);
          background: var(--ground-raised);
        }
        .history-langs {
          font-family: var(--font-mono);
          font-size: 11px;
          color: var(--signal);
          text-transform: uppercase;
          letter-spacing: 0.06em;
        }
        .history-snippet {
          font-size: 13px;
          color: var(--ink-dim);
        }
      `}</style>
    </div>
  )
}
